from kivy.graphics.context_instructions import PushMatrix, PopMatrix, Rotate
from kivy.base import runTouchApp
from kivy.uix.floatlayout import FloatLayout

from katana import Katana


if __name__ == '__main__':
    k = Katana(size_hint=(.1, .8), pos_hint={'center_x': .5, 'center_y': .5})
    k.angle = 90
    fl = FloatLayout()
    fl.add_widget(k)
    runTouchApp(fl)
