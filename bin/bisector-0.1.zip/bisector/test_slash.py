from kivy.animation import Animation
from kivy.graphics.context_instructions import PushMatrix, PopMatrix, Rotate
from kivy.base import runTouchApp

from slash import Slash


if __name__ == '__main__':
    sl = Slash(size_hint=(.1, .8), pos_hint={'center_x': .5, 'center_y': .5})
    anim1 = Animation(angle=180, temperature=1.)
    anim2 = Animation(angle=0, temperature=0.)
    anim = anim1 + anim2
    anim.repeat = True
    anim.start(sl)
    runTouchApp(sl)
