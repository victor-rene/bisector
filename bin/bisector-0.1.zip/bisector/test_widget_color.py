from kivy.animation import Animation
from kivy.base import runTouchApp
from kivy.graphics import Color, Rectangle
from kivy.properties import NumericProperty
from kivy.uix.widget import Widget


class MyWidget(Widget):
    
    temperature = NumericProperty()
    
    def __init__(self, **kwargs):
        super(MyWidget, self).__init__(**kwargs)
        with self.canvas:
            self.rect_clr = Color(0, 0, 0, 1)
            self.rect = Rectangle()
            Color(1, 1, 1, 1)
        self.bind(pos=self._update_rect, size=self._update_rect)
        
    def _update_rect(self, *args):
        self.rect.pos = self.pos
        self.rect.size = self.size
        
    def on_temperature(self, *args):
        h = .5 - self.temperature / 2.
        s = v = .9
        a = 1.
        # my past mistake is self.rect_clr = Color(h, s, v, a, mode='hsv')
        self.rect_clr.hsv = (h, s, v)
        

if __name__ == "__main__":
    my_wgt = MyWidget() 
    anim1 = Animation(temperature = 1.)
    anim2 = Animation(temperature = 0.)
    anim = anim1 + anim2
    anim.repeat = True
    anim.start(my_wgt)
    runTouchApp(my_wgt)
